#SNAKE

This is a snake game for the Hack platform, it is programmed in the Jack
language.


To load the game, open your `VMEmulator` and point it to vm-files directory.


The source code is located under `/source`.  I've kept the code pretty simple,
it should be easy to understand.  The only 'interesting' part might be the
random number generation, but thats a short wikipedia article to understand.


### How to play.
- Press any key to begin.  The key pressed is used to seed the RNG.

- Use the arrow keys to move the snake around to eat the food pellets.
- The game ends when the snake touches itself or runs into a wall, good luck.
